export PATH=$PATH:./vendor/bin:./node_modules/.bin
