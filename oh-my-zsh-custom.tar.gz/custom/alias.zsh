alias ls='ls --group-directories-first --time-style=+"%d.%m.%Y %H:%M" --color=auto -F'
alias ll='ls -la --group-directories-first --time-style=+"%d.%m.%Y %H:%M" --color=auto -F'
alias l='ls -lh --group-directories-first --time-style=+"%d.%m.%Y %H:%M" --color=auto -F'
alias la='ls -la --group-directories-first --time-style=+"%d.%m.%Y %H:%M" --color=auto -F'
alias grep='grep --color=tty -d skip'
alias cp="cp -i"                          # confirm before overwriting something
alias df='df -h'                          # human-readable sizes
alias free='free -m'                      # show sizes in MB
alias vp='vim PKGBUILD'
alias vs='vim SPLITBUILD'

#git in english pls
#alias git='LC_ALL=en_US git'
# Tells 'less' not to paginate if less than a page (git uses it and it's kinda annoying)
export LESS="-F -X $LESS"

#Convertir flac a mp3 desde la consola (porque puedo)
alias flac2mp3avconv='for f in *.flac; do avconv -i "$f" -ab 320k -map_metadata 0 -id3v2_version 3 "${f%.*}.mp3"; done'
alias flac2mp3='for f in *.flac; do ffmpeg -i "$f" -ab 320k -map_metadata 0 -id3v2_version 3 "${f%.*}.mp3"; done'
# sudo !! alias (just for fun)
alias fuck='sudo $(history -p \!\!)'
# Add an "alert" alias for long running commands. Use like so: # sleep 10; alert
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" "$(history|tail -n1|sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'
#set permissions (para los vhosts vieja)
alias setperm='sudo /var/www/vhosts/setperm.sh'
#cambiar la version de PHP (awanteee)
alias switch2php='sudo /home/mariano/phpswitch.sh'
# vim stuff
export EDITOR=vim
export VISUAL=vim
alias vi=vim
alias check-site-stats="curl -s -w 'Testing Website Response Time for :%{url_effective}\n\nLookup Time:\t\t%{time_namelookup}\nConnect Time:\t\t%{time_connect}\nPre-transfer Time:\t%{time_pretransfer}\nStart-transfer Time:\t%{time_starttransfer}\n\nTotal Time:\t\t%{time_total}\n' -o /dev/null"
alias inotify-max="sudo sysctl fs.inotify.max_user_watches=524288 && sudo sysctl -p"
alias awseb="aws elasticbeanstalk"
alias ssh-aws="ssh -i ~/ProjectsDocs/Syscon/keys/fitapi-prod.pem -l ec2-user"
# Github Copilot for CLI Alias
eval "$(github-copilot-cli alias -- "$0")"
